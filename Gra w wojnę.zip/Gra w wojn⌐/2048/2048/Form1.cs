﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2048
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
        private void PictureBox2_Click(object sender, EventArgs e)
        {

        }
        public static class GlobalData
        {

        }


        public void Form1_Load(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            int[] tab = new int[52];
            int x = 0;
            for (int i = 0; i < 52; i++)
            {
                tab[i] = x;
                if ((i + 1) % 4 == 0)
                    x++;
            }
            int[] talia1 = new int[26];
            int[] talia2 = new int[26];
            Random rand = new Random();
            for (int i = 0; i < 26; i++)
            {
                talia1[i] = -1;
            }
            for (int i = 0; i < 26; i++)
            {
                int n = rand.Next(52);
                if ((tab[n] == -1))
                {
                    i = i - 1;
                }
                else
                {
                    talia1[i] = tab[n];
                    tab[n] = -1;
                }
            }
            for (int i = 0; i < 26; i++)
            {
                int n = rand.Next(52);
                if ((tab[n] == -1))
                {
                    i = i - 1;
                }
                else
                {
                    talia2[i] = tab[n];
                    tab[n] = -1;
                }
            }
            string txt1 = "";
            string txt2 = "";
            for (int i = 0; i < 26; i++)
            {
                if (talia1[i] == 10)
                {
                    txt1 += 'a';
                }
                else
                if (talia1[i] == 11)
                {
                    txt1 += 'b';
                }
                else
                if (talia1[i] == 12)
                {
                    txt1 += 'c';
                }
                else
                txt1 += talia1[i].ToString();
            }
            for (int i = 0; i < 26; i++)
            {
                if (talia2[i] == 10)
                {
                    txt2 += 'a';
                }
                else
                if (talia2[i] == 11)
                {
                    txt2 += 'b';
                }
                else
                if (talia2[i] == 12)
                {
                    txt2 += 'c';
                }
                else
                    txt2 += talia2[i].ToString();
            }
            label1.Text = txt1;
            label2.Text = txt2;

        }
        public static int o=0;

        public void button1_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            string a= label1.Text;
            string b= label2.Text;

            int[] talia1 = new int[26];
            int[] talia2 = new int[26];
            for(int i=0;i<26;i++)
            {
                if (a[i] == '0')
                {
                    talia1[i] = 0;
                }
                else
                 if (a[i] == '1')
                {
                    talia1[i] = 1;
                }
                else
                 if (a[i] == '2')
                {
                    talia1[i] = 2;
                }
                else
                 if (a[i] == '3')
                {
                    talia1[i] = 3;
                }
                else
                 if (a[i] == '4')
                {
                    talia1[i] = 4;
                }
                else
                 if (a[i] == '5')
                {
                    talia1[i] = 5;
                }
                else
                 if (a[i] == '6')
                {
                    talia1[i] = 6;
                }
                if (a[i] == '7')
                {
                    talia1[i] = 7;
                }
                else
                     if (a[i] == '8')
                {
                    talia1[i] = 8;
                }
                else
                     if (a[i] == '9')
                {
                    talia1[i] = 9;
                }
                else
               if (a[i] == 'a')
                {
                    talia1[i] = 10;
                }
                else
                    if (a[i] == 'b')
                {
                    talia1[i] = 11;
                }
                else
                    if (a[i] == 'c')
                {
                    talia1[i] = 12;
                }
            }
            for (int i = 0; i < 26; i++)
            {
                if (b[i] == '0')
                {
                    talia2[i] = 0;
                }
                else
                 if (b[i] == '1')
                {
                    talia2[i] = 1;
                }
                else
                 if (b[i] == '2')
                {
                    talia2[i] = 2;
                }
                else
                 if (b[i] == '3')
                {
                    talia2[i] = 3;
                }
                else
                 if (b[i] == '4')
                {
                    talia2[i] = 4;
                }
                else
                 if (b[i] == '5')
                {
                    talia2[i] = 5;
                }
                else
                 if (b[i] == '6')
                {
                    talia2[i] = 6;
                }
                if (b[i] == '7')
                {
                    talia2[i] = 7;
                }
                else
                     if (b[i] == '8')
                {
                    talia2[i] = 8;
                }
                else
                     if (b[i] == '9')
                {
                    talia2[i] = 9;
                }
                else
               if (b[i] == 'a')
                {
                    talia2[i] = 10;
                }
                else
                    if (b[i] == 'b')
                {
                    talia2[i] = 11;
                }
                else
                    if (b[i] == 'c')
                {
                    talia2[i] = 12;
                }
            }





            if (talia2[o] == 0)
            {
                Image image2 = Image.FromFile("2.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 1)
            {
                Image image2 = Image.FromFile("3.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 2)
            {
                Image image2 = Image.FromFile("4.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 3)
            {
                Image image2 = Image.FromFile("5.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 4)
            {
                Image image2 = Image.FromFile("6.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 5)
            {
                Image image2 = Image.FromFile("7.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 6)
            {
                Image image2 = Image.FromFile("8.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            if (talia2[o] == 7)
            {
                Image image2 = Image.FromFile("9.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                 if (talia2[o] == 8)
            {
                Image image2 = Image.FromFile("10.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                 if (talia2[o] == 9)
            {
                Image image2 = Image.FromFile("11.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
           if (talia2[o] == 10)
            {
                Image image2 = Image.FromFile("12.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 11)
            {
                Image image2 = Image.FromFile("13.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 12)
            {
                Image image2 = Image.FromFile("14.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }





            if (talia1[o] == 0)
            {
                Image image3 = Image.FromFile("2.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 1)
            {
                Image image3 = Image.FromFile("3.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 2)
            {
                Image image3 = Image.FromFile("4.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 3)
            {
                Image image3 = Image.FromFile("5.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 4)
            {
                Image image3 = Image.FromFile("6.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 5)
            {
                Image image3 = Image.FromFile("7.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 6)
            {
                Image image3 = Image.FromFile("8.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            if (talia1[o] == 7)
            {
                Image image3 = Image.FromFile("9.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                 if (talia1[o] == 8)
            {
                Image image3 = Image.FromFile("10.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                 if (talia1[o] == 9)
            {
                Image image3 = Image.FromFile("11.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
           if (talia1[o] == 10)
            {
                Image image3 = Image.FromFile("12.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 11)
            {
                Image image3 = Image.FromFile("13.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 12)
            {
                Image image3 = Image.FromFile("14.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }



            if (talia1[o] > talia2[o])
            {
                textBox1.Text = Convert.ToString(int.Parse(textBox1.Text) + 1);
            }
            else
            if(talia1[o]<talia2[o])
            {
                textBox2.Text = Convert.ToString(int.Parse(textBox2.Text) + 1);
            }
            o = o + 1;
            if (o == 25)
            {
                button1.Enabled = false;
                kolejnaKartaToolStripMenuItem.Enabled = false;
                if (int.Parse(textBox1.Text)< int.Parse(textBox2.Text))
                {
                    MessageBox.Show("Wygrałeś Gratulacje !");
                }
                else
                if (int.Parse(textBox1.Text) > int.Parse(textBox2.Text))
                {
                    MessageBox.Show("Przegrałeś spróbuj ponownie");
                }
                else
                if (int.Parse(textBox1.Text) == int.Parse(textBox2.Text))
                {
                    MessageBox.Show("Remis");
                }
            }
        }
        private void Button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            kolejnaKartaToolStripMenuItem.Enabled = true;
            button1.Enabled = true;
            textBox1.Text = "0";
            textBox2.Text = "0";
            int[] tab = new int[52];
            int x = 0;
            for (int i = 0; i < 52; i++)
            {
                tab[i] = x;
                if ((i + 1) % 4 == 0)
                    x++;
            }
            int[] talia1 = new int[26];
            int[] talia2 = new int[26];
            Random rand = new Random();
            for (int i = 0; i < 26; i++)
            {
                talia1[i] = -1;
            }
            for (int i = 0; i < 26; i++)
            {
                int n = rand.Next(52);
                if ((tab[n] == -1))
                {
                    i = i - 1;
                }
                else
                {
                    talia1[i] = tab[n];
                    tab[n] = -1;
                }
            }
            for (int i = 0; i < 26; i++)
            {
                int n = rand.Next(52);
                if ((tab[n] == -1))
                {
                    i = i - 1;
                }
                else
                {
                    talia2[i] = tab[n];
                    tab[n] = -1;
                }
            }
            string txt1 = "";
            string txt2 = "";
            for (int i = 0; i < 26; i++)
            {
                if (talia1[i] == 10)
                {
                    txt1 += 'a';
                }
                else
                if (talia1[i] == 11)
                {
                    txt1 += 'b';
                }
                else
                if (talia1[i] == 12)
                {
                    txt1 += 'c';
                }
                else
                    txt1 += talia1[i].ToString();
            }
            for (int i = 0; i < 26; i++)
            {
                if (talia2[i] == 10)
                {
                    txt2 += 'a';
                }
                else
                if (talia2[i] == 11)
                {
                    txt2 += 'b';
                }
                else
                if (talia2[i] == 12)
                {
                    txt2 += 'c';
                }
                else
                    txt2 += talia2[i].ToString();
            }
            label1.Text = txt1;
            label2.Text = txt2;
            o = 0;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void autorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Jakub Sachajko 3B");
        }

        private void nowaGraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
            kolejnaKartaToolStripMenuItem.Enabled = true;
            button1.Enabled = true;
            textBox1.Text = "0";
            textBox2.Text = "0";
            int[] tab = new int[52];
            int x = 0;
            for (int i = 0; i < 52; i++)
            {
                tab[i] = x;
                if ((i + 1) % 4 == 0)
                    x++;
            }
            int[] talia1 = new int[26];
            int[] talia2 = new int[26];
            Random rand = new Random();
            for (int i = 0; i < 26; i++)
            {
                talia1[i] = -1;
            }
            for (int i = 0; i < 26; i++)
            {
                int n = rand.Next(52);
                if ((tab[n] == -1))
                {
                    i = i - 1;
                }
                else
                {
                    talia1[i] = tab[n];
                    tab[n] = -1;
                }
            }
            for (int i = 0; i < 26; i++)
            {
                int n = rand.Next(52);
                if ((tab[n] == -1))
                {
                    i = i - 1;
                }
                else
                {
                    talia2[i] = tab[n];
                    tab[n] = -1;
                }
            }
            string txt1 = "";
            string txt2 = "";
            for (int i = 0; i < 26; i++)
            {
                if (talia1[i] == 10)
                {
                    txt1 += 'a';
                }
                else
                if (talia1[i] == 11)
                {
                    txt1 += 'b';
                }
                else
                if (talia1[i] == 12)
                {
                    txt1 += 'c';
                }
                else
                    txt1 += talia1[i].ToString();
            }
            for (int i = 0; i < 26; i++)
            {
                if (talia2[i] == 10)
                {
                    txt2 += 'a';
                }
                else
                if (talia2[i] == 11)
                {
                    txt2 += 'b';
                }
                else
                if (talia2[i] == 12)
                {
                    txt2 += 'c';
                }
                else
                    txt2 += talia2[i].ToString();
            }
            label1.Text = txt1;
            label2.Text = txt2;
            o = 0;

        }

        private void kolejnaKartaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            string a = label1.Text;
            string b = label2.Text;

            int[] talia1 = new int[26];
            int[] talia2 = new int[26];
            for (int i = 0; i < 26; i++)
            {
                if (a[i] == '0')
                {
                    talia1[i] = 0;
                }
                else
                 if (a[i] == '1')
                {
                    talia1[i] = 1;
                }
                else
                 if (a[i] == '2')
                {
                    talia1[i] = 2;
                }
                else
                 if (a[i] == '3')
                {
                    talia1[i] = 3;
                }
                else
                 if (a[i] == '4')
                {
                    talia1[i] = 4;
                }
                else
                 if (a[i] == '5')
                {
                    talia1[i] = 5;
                }
                else
                 if (a[i] == '6')
                {
                    talia1[i] = 6;
                }
                if (a[i] == '7')
                {
                    talia1[i] = 7;
                }
                else
                     if (a[i] == '8')
                {
                    talia1[i] = 8;
                }
                else
                     if (a[i] == '9')
                {
                    talia1[i] = 9;
                }
                else
               if (a[i] == 'a')
                {
                    talia1[i] = 10;
                }
                else
                    if (a[i] == 'b')
                {
                    talia1[i] = 11;
                }
                else
                    if (a[i] == 'c')
                {
                    talia1[i] = 12;
                }
            }
            for (int i = 0; i < 26; i++)
            {
                if (b[i] == '0')
                {
                    talia2[i] = 0;
                }
                else
                 if (b[i] == '1')
                {
                    talia2[i] = 1;
                }
                else
                 if (b[i] == '2')
                {
                    talia2[i] = 2;
                }
                else
                 if (b[i] == '3')
                {
                    talia2[i] = 3;
                }
                else
                 if (b[i] == '4')
                {
                    talia2[i] = 4;
                }
                else
                 if (b[i] == '5')
                {
                    talia2[i] = 5;
                }
                else
                 if (b[i] == '6')
                {
                    talia2[i] = 6;
                }
                if (b[i] == '7')
                {
                    talia2[i] = 7;
                }
                else
                     if (b[i] == '8')
                {
                    talia2[i] = 8;
                }
                else
                     if (b[i] == '9')
                {
                    talia2[i] = 9;
                }
                else
               if (b[i] == 'a')
                {
                    talia2[i] = 10;
                }
                else
                    if (b[i] == 'b')
                {
                    talia2[i] = 11;
                }
                else
                    if (b[i] == 'c')
                {
                    talia2[i] = 12;
                }
            }





            if (talia2[o] == 0)
            {
                Image image2 = Image.FromFile("2.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 1)
            {
                Image image2 = Image.FromFile("3.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 2)
            {
                Image image2 = Image.FromFile("4.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 3)
            {
                Image image2 = Image.FromFile("5.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 4)
            {
                Image image2 = Image.FromFile("6.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 5)
            {
                Image image2 = Image.FromFile("7.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 6)
            {
                Image image2 = Image.FromFile("8.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            if (talia2[o] == 7)
            {
                Image image2 = Image.FromFile("9.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                 if (talia2[o] == 8)
            {
                Image image2 = Image.FromFile("10.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                 if (talia2[o] == 9)
            {
                Image image2 = Image.FromFile("11.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
           if (talia2[o] == 10)
            {
                Image image2 = Image.FromFile("12.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 11)
            {
                Image image2 = Image.FromFile("13.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia2[o] == 12)
            {
                Image image2 = Image.FromFile("14.png");
                pictureBox4.Image = image2;
                pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            }





            if (talia1[o] == 0)
            {
                Image image3 = Image.FromFile("2.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 1)
            {
                Image image3 = Image.FromFile("3.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 2)
            {
                Image image3 = Image.FromFile("4.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 3)
            {
                Image image3 = Image.FromFile("5.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 4)
            {
                Image image3 = Image.FromFile("6.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 5)
            {
                Image image3 = Image.FromFile("7.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 6)
            {
                Image image3 = Image.FromFile("8.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            if (talia1[o] == 7)
            {
                Image image3 = Image.FromFile("9.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                 if (talia1[o] == 8)
            {
                Image image3 = Image.FromFile("10.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                 if (talia1[o] == 9)
            {
                Image image3 = Image.FromFile("11.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
           if (talia1[o] == 10)
            {
                Image image3 = Image.FromFile("12.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 11)
            {
                Image image3 = Image.FromFile("13.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
                if (talia1[o] == 12)
            {
                Image image3 = Image.FromFile("14.png");
                pictureBox3.Image = image3;
                pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            }



            if (talia1[o] > talia2[o])
            {
                textBox1.Text = Convert.ToString(int.Parse(textBox1.Text) + 1);
            }
            else
            if (talia1[o] < talia2[o])
            {
                textBox2.Text = Convert.ToString(int.Parse(textBox2.Text) + 1);
            }
            o = o + 1;
            if (o == 25)
            {
                button1.Enabled = false;
                kolejnaKartaToolStripMenuItem.Enabled = false;
                if (int.Parse(textBox1.Text) < int.Parse(textBox2.Text))
                {
                    MessageBox.Show("Wygrałeś Gratulacje !");
                }
                else
                if (int.Parse(textBox1.Text) > int.Parse(textBox2.Text))
                {
                    MessageBox.Show("Przegrałeś spróbuj ponownie");
                }
                else
                if (int.Parse(textBox1.Text) == int.Parse(textBox2.Text))
                {
                    MessageBox.Show("Remis");
                }
            }
        }

        private void infoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}

